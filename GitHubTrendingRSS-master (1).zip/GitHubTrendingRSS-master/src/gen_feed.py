# -*- coding: utf-8 -*-
# copyright Duccio Meconcelli 2025
# licenza MIT


import xml.etree.ElementTree as ET
from dateutil import parser
from datetime import datetime, timezone
import email.utils  # Per formattare le date in RFC 822
import html  # Per fare l'escape di caratteri speciali nell'HTML
import logging  # Aggiunto import


def create_rss_feed(
    repos,
    feed_url,
    title="GitHub Trending Repositories",
    description="The most popular repositories on GitHub",
):
    """
    Creates an RSS 2.0 feed from GitHub repositories

    Parameters:
    repos (list): List of organized repositories (should include 'telegraph_url')
    feed_url (str): The public URL where this feed will be hosted (used for channel link)
    title (str): Feed title
    description (str): Feed description

    Returns:
    str: RSS 2.0 feed in XML format
    """
    # Create root element <rss>
    rss = ET.Element("rss")
    rss.set("version", "2.0")
    # Aggiungi namespace atom per link self
    rss.set("xmlns:atom", "http://www.w3.org/2005/Atom")

    # Create <channel> element
    channel = ET.SubElement(rss, "channel")

    # Add channel details
    ET.SubElement(channel, "title").text = title
    ET.SubElement(channel, "link").text = feed_url
    # Aggiungi link atom:self per una migliore scoperta del feed
    ET.SubElement(
        channel,
        "{http://www.w3.org/2005/Atom}link",
        href=feed_url,
        rel="self",
        type="application/rss+xml",
    )
    ET.SubElement(channel, "description").text = description
    ET.SubElement(channel, "language").text = "it-it"  # Cambiato in italiano

    # Data dell'ultimo aggiornamento del feed (formato RFC 822)
    current_time_utc = datetime.now(timezone.utc)
    last_build_date = email.utils.format_datetime(current_time_utc)
    ET.SubElement(channel, "lastBuildDate").text = last_build_date
    # Opzionale: ET.SubElement(channel, "ttl").text = "60" # Time To Live in minuti

    # Add each repository as an <item>
    for repo in repos:
        item = ET.SubElement(channel, "item")

        # Format title with repo name, stars, and language emoji
        lang_emoji = "📝"  # Default emoji
        # Potresti mappare linguaggi comuni a emoji specifici qui se vuoi
        if repo.get("language") == "Python":
            lang_emoji = "🐍"
        elif repo.get("language") == "JavaScript":
            lang_emoji = "📜"
        elif repo.get("language") == "Go":
            lang_emoji = "🐹"
        elif repo.get("language") == "Rust":
            lang_emoji = "🦀"
        elif repo.get("language") == "TypeScript":
            lang_emoji = "🟦"
        elif repo.get("language") == "Java":
            lang_emoji = "☕"
        elif repo.get("language") == "C#":
            lang_emoji = "♯"
        elif repo.get("language") == "PHP":
            lang_emoji = "🐘"
        elif repo.get("language") == "C++":
            lang_emoji = "💻"
        # ... aggiungi altre mappature

        item_title = f"{lang_emoji} {repo['name']} ({repo['stars']} ⭐)"
        ET.SubElement(item, "title").text = item_title

        ET.SubElement(item, "link").text = repo["url"]
        ET.SubElement(item, "guid", isPermaLink="true").text = repo["url"]

        # Usiamo html.escape per sicurezza sui dati forniti dall'utente (descrizione, nome repo, ecc.)
        repo_name_safe = html.escape(repo["name"])
        # Modifica: Controlla esplicitamente per None dopo il get
        repo_desc = repo.get("description")  # Ottieni il valore o None
        repo_desc_safe = html.escape(repo_desc if repo_desc is not None else "N/A")

        repo_lang = repo.get("language")
        repo_lang_safe = html.escape(repo_lang if repo_lang is not None else "N/A")

        repo_license = repo.get("license")
        repo_license_safe = html.escape(repo_license if repo_license is not None else "N/A")

        # Per owner, la logica attuale con il dizionario vuoto come default funziona bene
        # perché .get("name", "N/A") viene chiamato su {} se owner non esiste o è None (se gestito prima)
        # Ma per essere ultra sicuri e coerenti:
        owner_dict = repo.get("owner", {})  # Ottiene il dizionario owner o {}
        owner_name = (
            owner_dict.get("name") if owner_dict else None
        )  # Ottiene il nome se owner_dict non è vuoto/None
        owner_name_safe = html.escape(owner_name if owner_name is not None else "N/A")

        # Topics
        topics_html = ""
        # Modifica: Usa il default [] direttamente qui è sicuro perché iteriamo
        topics_list = repo.get("topics", [])
        if topics_list:  # Controlla se la lista non è vuota
            topics_html = " ".join(
                f'<span style="background-color: #f0f0f0; padding: 2px 5px; border-radius: 3px; margin-right: 3px; font-size: 0.9em;">{html.escape(topic)}</span>'
                for topic in topics_list  # Usa la lista ottenuta
            )
            topics_html = f"<p><strong>🏷️ Topics:</strong> {topics_html}</p>"

        description_html = f"""
        <![CDATA[
        <p>👤 <strong>Owner:</strong> {owner_name_safe}</p>
        <p>📝 <strong>Repository:</strong> <a href="{html.escape(repo['url'])}">{repo_name_safe}</a></p>
        <p>📄 <strong>Descrizione:</strong> {repo_desc_safe}</p>
        <p>⭐ <strong>Stelle:</strong> {repo['stars']}</p>
        <p>🍴 <strong>Forks:</strong> {repo['forks']}</p>
        <p>💻 <strong>Linguaggio:</strong> {repo_lang_safe}</p>
        {topics_html}
        <p>📜 <strong>Licenza:</strong> {repo_license_safe}</p>
        <p>⏰ <strong>Creato il:</strong> {html.escape(repo.get('created_at') or 'N/A')}</p>
        <p>🔄 <strong>Ultimo Aggiornamento:</strong> {html.escape(repo.get('updated_at') or 'N/A')}</p>
        <hr>
        <p><a href="{html.escape(repo['url'])}">Visita il Repository su GitHub</a></p>
        ]]>
        """
        ET.SubElement(item, "description").text = description_html

        # Create RFC 822 formatted dates for pubDate (using updated_at for relevance)
        # Modifica: La logica qui con 'or' gestisce già il caso None
        pub_date_source = repo.get("updated_at") or repo.get("created_at")
        if pub_date_source:
            try:
                pub_date_dt = parser.parse(pub_date_source)
                if pub_date_dt.tzinfo is None:
                    pub_date_dt = pub_date_dt.replace(tzinfo=timezone.utc)
                else:
                    pub_date_dt = pub_date_dt.astimezone(timezone.utc)

                pub_date_str = email.utils.format_datetime(pub_date_dt)
                ET.SubElement(item, "pubDate").text = pub_date_str
            except Exception as e:
                print(f"Warning: Failed to parse date '{pub_date_source}' for {repo['name']}: {e}")
                ET.SubElement(item, "pubDate").text = last_build_date  # Fallback
        else:
            ET.SubElement(item, "pubDate").text = last_build_date  # Fallback

        # Aggiungi categoria/tag per il linguaggio
        if repo.get("language"):
            ET.SubElement(item, "category").text = repo["language"]
        # Aggiungi categorie/tag per i topics
        # Modifica: Usa la lista ottenuta prima
        for topic in topics_list:  # Usa topics_list invece di chiamare get di nuovo
            ET.SubElement(item, "category").text = topic

    # Convert XML tree to string
    # ET.indent(rss) # Aggiunge indentazione per leggibilità (richiede Python 3.9+)
    xml_string = ET.tostring(rss, encoding="utf-8", method="xml")

    # Add XML declaration and decode
    xml_declaration = '<?xml version="1.0" encoding="UTF-8" ?>\n'
    return xml_declaration + xml_string.decode("utf-8")


def save_rss_feed(rss_feed, filename="github_trending.xml"):
    """
    Saves the RSS feed to a file

    Parameters:
    rss_feed (str): RSS feed content
    filename (str): Output file name

    Returns:
    bool: True if the save was successful, False otherwise
    """
    try:
        with open(filename, "w", encoding="utf-8") as file:
            file.write(rss_feed)
        return True
    except Exception as e:
        print(f"Error while saving the file: {e}")
        return False


